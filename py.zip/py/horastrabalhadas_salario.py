#Horas trabalhadas e salário
#Exercício extra 7
#Rebeca Barossi
import os
titulo = ''' 
Horas trabalhadas e salário
----- ----------- - -------
'''
info = '''
- Horas trabalhadas vale metade do salário mínimo;
- Salário bruto equivale ao número de horas trabalhadas multiplicado pelo valor da hora trabalhada;
- Imposto equivale a 3% do salário bruto;
- Salário a receber equivale ao salário bruto menos o imposto.
'''
print(titulo)
print (info)
#Entrada de dados
horas_trabalhadas = float(input("Digite as horas trabalhadas: "))
salario_minimo = float(input("Digite o valor do salário mínimo: "))

#Processamento do Cálculo
valor_hora_trabalhada = round(salario_minimo/2, 2)
salario_bruto = round(horas_trabalhadas * valor_hora_trabalhada, 2)
imposto = round(salario_bruto * 3 / 100, 2)
salario_receber = round(salario_bruto - imposto, 2)

#Saída
print(titulo)
print(info)
print(f"Salário a receber: {salario_receber}")
print(salario_bruto)
print(valor_hora_trabalhada)
print(imposto)