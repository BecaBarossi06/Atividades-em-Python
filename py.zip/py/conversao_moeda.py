#Converter real para dólar
#Exercício 2
#Rebeca Barossi
titulo = ''' 
conversão de moeda
--------- -- -----
'''
print(titulo)

#Entrada de dados
valor_real = float(input("Digite o valor em real: "))
valor_dolar = float(input("Digite o valor do dólar: "))

#Processamento do Cálculo
conversao = valor_real * valor_dolar

#Saída
print(titulo)
print(f"O valor em real é: {valor_real}\n" + f"O valor do dólar é: {valor_dolar}\n" + f"Real em dólar: {conversao}")