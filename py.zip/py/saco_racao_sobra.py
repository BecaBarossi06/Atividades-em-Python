#Calcular saco de ração
#Exercício extra 8
#Rebeca Barossi
import os
titulo = ''' 
Saco de ração após 5 dias
---- -- ----- ---- - ----
'''

print(titulo)

#Entrada de dados
peso_sacoracao = float(input("Digite quantos quilos tem o saco de ração "))
racao_gato1 = float(input("Digite a quantidade de ração, em grama, fornecida por dia para o primeiro gato: "))
racao_gato2 = float(input("Digite a quantidade de ração, em grama, fornecida por dia para o segundoo gato: "))

#convertendo o peso do saco de kg para gramas
peso_saco_grama = peso_sacoracao * 1000

#Processamento do Cálculo
racao_total = (racao_gato1 + racao_gato2) * 5

#Quanto sobre de ração apos 5 dias
sobra_gramas = peso_saco_grama - racao_total

#Convertendo o valor de gramas para kg
sobra_kg = sobra_gramas / 1000

#Saída
print(f"Após 5 dias, sobrará {sobra_kg}KG de ração no saco de {peso_sacoracao}KG")