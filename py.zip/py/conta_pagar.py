#Calcular contas atrasadas com multa de 2% cada e quanto sobrará do salário
#Exercício extra 10
#Rebeca Barossi
import os
titulo = ''' 
Restante do salário após pagar conta
-------- -- ------- ---- ----- -----
'''

print(titulo)

#Entrada de dados
salario = float(input("Digite o seu salário: "))
conta1 = float(input("Digite o valor da primeira conta: "))
conta2 = float(input("Digite o valor da segunda conta: "))


#Processamento do Cálculo
multa1 = conta1 * 2 / 100
multa2 = conta2 * 2 / 100
soma_multas = conta1 + multa1 + conta2 + multa2
resto_salario = salario - soma_multas

#Saída
print(f"Dê {salario} sobrará após pagar as contas: {resto_salario}")