#Calcular lucro e margem de lucro
#Exercício 4
#Rebeca Barossi
import os
titulo = ''' 
Lucro e margem de lucro
----- - ------ -- -----
'''
print(titulo)

#Entrada de dados
valor_produto = float(input("Digite o valor do produto: "))
custo_produto = float(input("Digite o custo ao adquiri-lo: "))

#Processamento do Cálculo
lucro = valor_produto - custo_produto
margem_lucro = lucro / custo_produto * 100

#Saída
os.system("cls")
print(titulo)
print(f"Valor do produto: {valor_produto}\n" + f"Lucro obtido: {lucro}\n" + f"Margem de lucro: {margem_lucro}")