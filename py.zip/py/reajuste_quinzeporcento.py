#Ler e imprimir novo ajuste de 15%
#Exercício extra 3
#Rebeca Barossi
import os
titulo = ''' 
Valor com ajuste de 15%
----- --- ------ -- ---
'''
print(titulo)

#Entrada de dados
valor = float(input("Digite o valor da aplicação: "))

#Processamento do Cálculo
reajuste = valor * 15 / 100
valor_reajustado = valor + reajuste

#Saída
print(titulo)
print(f"Novo valor de aplicação com o reajuste de 15%: {valor_reajustado}")