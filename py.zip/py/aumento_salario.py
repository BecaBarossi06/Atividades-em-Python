#Calculo de aumento de salário
#Exercício extra 4
#Rebeca Barossi
import os
titulo = ''' 
Cálculo de aumento de salário
------- -- ------- -- -------
'''
print(titulo)

#Entrada de dados
salario = float(input("Digite o valor do salario: "))
percentual_aumento = float(input("Digite o percentual de aumento: "))

#Processamento do Cálculo
aumento = salario * percentual_aumento / 100
novo_salario = salario + aumento
#Saída
print(titulo)
print(f"Valor do novo salário: {novo_salario}")