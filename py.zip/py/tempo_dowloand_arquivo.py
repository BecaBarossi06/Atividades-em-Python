#Velocidade para fazer dowloand de arquivo em bits
#Exercício extra 1
#Rebeca Barossi
import os
titulo = ''' 
Tempo para dowloand de arquivo
----- ---- -------- -- -------
'''
print(titulo)

#Entrada de dados
tamanho_arquivo = float(input("Digite o tamanho do arquivo em bits: "))
velociade_conexao = float(input("Digite a velocidade da conexão em bps: "))

#Processamento do Cálculo
tempo_segundos = tamanho_arquivo / velociade_conexao

#convertendo o tempo em segundo para ser mais legível
horas = int(tempo_segundos // 3600)
minutos = int((tempo_segundos % 3600) // 60)
segundos = tempo_segundos % 60

#Saída
print(titulo)
print(f"Tempo para dowloand: {horas}h {minutos}min {segundos}s")