#Idade da pessoa nesse momento e idade da pessoa em 2030
#Exercício extra 5
#Rebeca Barossi
import os
titulo = ''' 
Idade atual e em 2030
----- ----- - -- ----
'''
print(titulo)

#Entrada de dados
ano_nasc = float(input("Digite o seu ano de nascimento: "))
ano_atual = float(input("Digite o ano atual: "))

#Processamento do Cálculo
idade_atual = ano_atual - ano_nasc
idade_2030 = 2030 - ano_nasc

#Saída
print(titulo)
print(f"idade atual {idade_atual} e idade em 2030: {idade_2030}")