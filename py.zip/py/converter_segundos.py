#Converter segundos para minutos/segundos
#Exercício extra 6
#Rebeca Barossi
import os
titulo = ''' 
Converter segundos em minutos segundos
--------- -------- -- ------- --------
'''
print(titulo)

#Entrada de dados
segundo = float(input("Digite os segundos: "))

#Processamento do Cálculo
minutos = int((segundo % 3600) // 60)
tempo_segundo = segundo % 60

#Saída
print(titulo)
print(f"O tempo em minutos e segundos é: {minutos}min {tempo_segundo}s")