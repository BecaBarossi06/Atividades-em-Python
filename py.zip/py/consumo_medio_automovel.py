#Consumo médio de um automovel
#Exercício extra 2
#Rebeca Barossi
import os
titulo = ''' 
Consumo médio de um automovel
------- ----- -- -- ---------
'''
print(titulo)

#Entrada de dados
distancia_total = float(input("Digite a distância total percorrida: "))
volume_combustivel = float(input(f"Digite (em litros) o quanto de combustível foi necessário para percorrer {distancia_total} KM: "))

#Processamento do Cálculo
consumo_medio = distancia_total / volume_combustivel 


#Saída
print(titulo)
print(f"Consumo médio do automóvel: {consumo_medio} Km/l")