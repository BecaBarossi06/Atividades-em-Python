#Calcular quantos ingressos devem ser vendidos para alcançar o custo do espetáculo
#Exercício extra 9
#Rebeca Barossi
import os
titulo = ''' 
Ingressos para vender em espetáculo teatral
--------  ---- ------ -- ---------- -------
'''

print(titulo)

#Entrada de dados
custo_espetaculo = float(input("Digite o custo do espetáculo: "))
valor_ingresso = float(input("Digite o valor do ingresso: "))


#Processamento do Cálculo
ingresso_necessario = custo_espetaculo / valor_ingresso


#Saída
print(f"Deverá ser vendido {ingresso_necessario} ingressos para o custo ser alcançado")