#Aumento percentual no estoque
#Exercício 5
#Rebeca Barossi
import os
titulo = ''' 
Aumento percentual no estoque
------- ---------- -- -------
'''
print(titulo)

#Entrada de dados
unidade_produto = float(input("Digite a quantidade de produto: "))
nova_remessa = float(input("Digite quantos porcento aumentou o estoque: "))

#Processamento do Cálculo
novo_estoque = unidade_produto + (unidade_produto * nova_remessa / 100)

#Saída
os.system("cls")
print(titulo)
print(f"Quantidade do produto: {unidade_produto}\n" + f"Aumento em porcentagem: {nova_remessa}\n" + f"Novo estoque: {novo_estoque}")