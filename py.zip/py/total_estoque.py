#Contagem de valor total do estoque
#Exercício 3
#Rebeca Barossi
import os
titulo = ''' 
Valor total do estoque
----- ----- -- -------
'''
print(titulo)

#Entrada de dados
unidade_produto = float(input("Digite a quantidade do produto: "))
valor_produto = float(input("Digite o valor do produto: "))

#Processamento do Cálculo
total_estoque = unidade_produto * valor_produto

#Saída
os.system("cls")
print(titulo)
print(f"Quantidade de produto: {unidade_produto}\n" + f"Valor do produto: {valor_produto}\n" + f"Total do estoque: {total_estoque}")