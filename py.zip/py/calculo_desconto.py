#Calcular o desconto em uma compra
#Exercício 1
#Rebeca Barossi
titulo = ''' 
Cálculo de desconto
------- -- --------
'''
print(titulo)

#Entrada de dados
valor_produto = float(input("Digite o valor do produto: "))
valor_desconto = float(input("Digite o valor do desconto: "))

#Processamento do Cálculo
desconto = valor_produto*valor_desconto/100
valor_final = valor_produto - desconto

#Saída
print(f"O valor do produto é: {valor_produto}\n" + f"O valor do desconto é: {valor_desconto}\n" + f"O valor final a ser pago com o desconto aplicado será: {valor_final}")