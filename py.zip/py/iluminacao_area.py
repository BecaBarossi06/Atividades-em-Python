#Calcular área e iluminação
#Exercício extra 11
#Rebeca Barossi
import os
titulo = ''' 
Área e  iluminação
---- - -----------
'''

print(titulo)

#Entrada de dados
largura = float(input("Digite a largura em metros: "))
comprimento = float(input("Digite o comprimento em metros: "))


#Processamento do Cálculo
area = comprimento * largura
potencia = area * 18

#Saída
print(f"A área é de {area}m² e a potência necessária para a iluminação será de {potencia}W")